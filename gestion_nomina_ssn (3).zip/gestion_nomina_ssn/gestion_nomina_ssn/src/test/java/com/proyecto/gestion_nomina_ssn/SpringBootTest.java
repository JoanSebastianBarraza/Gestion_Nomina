package com.proyecto.gestion_nomina_ssn;

public @interface SpringBootTest {

}
