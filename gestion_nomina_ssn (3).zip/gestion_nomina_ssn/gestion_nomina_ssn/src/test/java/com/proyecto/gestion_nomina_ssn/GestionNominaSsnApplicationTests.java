package com.proyecto.gestion_nomina_ssn;


@SpringBootTest
class GestionNominaSsnApplicationTests {

	@Test
	void contextLoads() {
	}

}
