package com.proyecto.gestion_nomina_ssn.model;

public enum Role {
    ADMIN,
    USER
}
