package com.proyecto.gestion_nomina_ssn.service;

import com.proyecto.gestion_nomina_ssn.model.User;

public interface IEmailService {
    void sendPagoEmail();
}
